		        iKey Driver Version 4.0.0.1014
		                  ReadMe.txt
			Copyright (c) 2007 SafeNet, Inc.
		              All Rights Reserved.
----------------------------------------------------------------------------                        

Thank you for choosing the iKey Driver from SafeNet! 
The iKey Driver contains the drivers and libraries used for SafeNet's
iKey Security Tokens.

This ReadMe file provides information on product installation and 
uninstallation, new features, last-minute news and where to go  
for more information or to report problems.

------------------
 Table of Contents
------------------

1.0 Installing iKey Driver
    1.1 Compatibility
    1.2 Installation
        1.2.1 Installation by CD
        1.2.2 Installation by Windows Group Policy
        1.2.3 Installation by the System Management Server
            1.2.3.1 Package Creation
            1.2.3.2 Create Software Distribution Object
            1.2.3.3 Create Advertisement to Deploy the Package
2.0 What's New in This Release?
    2.1 Problems Fixed in This Release
3.0 Late-Breaking News
4.0 Known Problems
5.0 Reporting Problems

---------------------------
 1.0 INSTALLING IKEY DRIVER
---------------------------

------------------
 1.1 Compatibility
------------------

IMPORTANT! Please read this section completely BEFORE running the
iKey Driver setup program to ensure that you are aware of any installation 
issues that may pertain to your system and environment.

 1. A Windows-based installation program is provided to make installation
    of the iKey Driver quick and easy. The installation program runs only 
    on the following operating systems:

    for IKEYDRVR.MSI:
    - Windows 2000
    - Windows 2003
    - Windows XP
    - Windows VISTA

    All systems require a functional USB controller to be installed prior
    to installation of the iKey Driver.

 2. On Toshiba Model T440 CDX laptops, iKey Security Tokens will not be
    recognized. This is due to an incompatibility with the USB controller
    used in the iKey Security Tokens. Currently, there is no known 
    workaround for this issue.

 3. iKey 2000 SDK/Authentication Solution Software

    - When upgrading the iKey Components on a system with the iKey 2000 SDK 
      or iKey 2000 Authentication Solution software installed, you must 
      restart your system upon completion of the iKey Components installation. 
      This is required for the CIP service to see any new readers that may 
      have been created during iKey Components installation.

    - Under Windows XP/2003, the Start CIP on Boot option must be disabled for 
      version 4.5 or version 4.6 of iKey 2000 SDK or iKey 2000 
      Authentication Solution software. If you already have an installation 
      of iKey 2000 SDK or iKey 2000 Authentication Solution v4.5 or v4.6 
      software installed, perform the following steps to disable
      the Start CIP on boot option:

	1. Open Control Panel.
	2. Select Switch to classic view.
	3. Open the Administrative Tools folder.
	4. Open the Services control panel applet.
	5. Select DkeyServ.
	6. For StartType, select Disabled.
	7. Restart your system.

      If you have not yet installed the iKey 2000 SDK or iKey 2000 Authentication
      v4.5 or v4.6 software, deselect the Start CIP on boot option when 
      performing the installation.

    - On all platforms, if a newer version of the iKey Components is installed,
      and you install the iKey 2000 SDK or iKey 2000 Authentication Solutions
      software, the operating system may not be able to find the appropriate
      device driver upon installation of an iKey Security Token. In this case, 
      you must rerun the iKey Components installation to repair the system.

 4. iKey 1000 Components Installer (iKeyAll.exe)

    - When installing version 2.6 through version 3.x.x of the iKey Component 
      Installer, if a newer version of the iKey Driver is already installed, 
      the iKey Components installer will fail to install any files. To resolve
      this issue you must:

	1. Uninstall the iKey Driver.
	2. Install iKey Components.
	3. Re-install the iKey Driver.

 5. Windows 2000/XP/2003

    - When upgrading the driver from version 2.6 through 4.x, all iKey 
      Security Tokens must be removed PRIOR to installation. This prevents
      you from being logged off during the driver upgrade if you are
      using an iKey Security Token for Smart Card logon.

    - When upgrading the iKey Driver from version 4.x, you may be prompted
      by the system to restart your computer. Please click NO in ALL
      system restart message boxes until iKey Driver installation is complete. 
      Failure to do so may cause iKey Driver installation to fail. If this 
      occurs, rerun the setup program to repair the installation.

    - When upgrading the driver from version 2.6 through 4.x, error messages
      may exist in the System Event Log after installation. These error
      messages indicate that the installation could not create a unique reader
      name. This is by design and has no effect on the iKey Driver installation.

    - When uninstalling the iKey Driver, all iKey Security Tokens must be
      removed PRIOR to uninstallation. This prevents you from being logged off
      during driver uninstallation if you are using an iKey Security Token for
      Smart Card logon.

    - When uninstalling version 2.6 through 4.x of the driver, you must restart
      your system prior to installing the new version of the driver.

 6. If you are planning to upgrade your operating system, uninstall the iKey 
    Driver BEFORE you perform the system upgrade. After you have upgraded your
    system, you can then re-install the iKey Driver.

 7. For Windows 2000/2003 and Windows XP, installation of a iKey Security Token must 
    be performed per-USB port, per-USB hub.  

-----------------
 1.2 Installation
-----------------
iKey driver can be installed in the following ways:

 --------------------------
   1.2.1 Installation by CD
 --------------------------

 The following instructions assume you are installing the iKey software 
 using a CD, and  that you are installing from CD-ROM drive D. If a drive 
 other than drive D is used, substitute D: with the appropriate drive letter. 
 (If installing from the Internet, double-click the file you downloaded to 
 start the installation process.)

  - Insert the CD into the CD-ROM drive.

  - If CD autorun is set, the installation should start. If not, from the Start 
    menu, select Run. The Run dialog box appears. 

    Type msiexec /I D:\IKEYDRVR.MSI at the Open prompt and click OK, where
    D is the CD Drive.
       
  - Follow the on-screen instructions to complete the installation. 
     
  - You can access this readme file from the 
    %SystemDrive%\Program Files\SafeNet\iKey Driver folder, where
    %SystemDrive% is the system drive later of where Windows is installed. 

 --------------------------------------------
   1.2.2 Installation by Windows Group Policy
 --------------------------------------------

 Assumption: Client machine is part of a domain using a Windows 2000 machine 
 as domain controller.

 Go to the domain controller machine and perform the following steps:

  1. Start mmc.exe.
  2. Using the option from the main menu of the mmc window open the "Add/Remove 
     Snap-in" dialog. Select the "Group Policy" Object, click on Add
  3. Expand the Default Domain Policy object in the MMC Console window to 
     select the Software installation node under Computer Configuration - Software 
     Settings.
  4. Right click on Software Installation and select New->Package option.
  5. Browse to open the iKeyDriver MSI installer IKEYDRVR.MSI and click on 
     Open. (By default the deployment method will be "Assign.")
  6. Select the new package created in Step 5 above and right-click to view the 
     package properties.
  7. Select the "Uninstall this application when it falls outside the scope of 
     management" 
     option from the Deploy Software tab and click OK.
  8. The package will now be installed and available in the Add/Remove Programs 
     applet in the control panel on the client system on the next logon.

 Now the client machine only needs a reboot to install or remove the software.

 ----------------------------------------------------
   1.2.3 Installation by the System Management Server
 ----------------------------------------------------

 Assumption: Client's machine is part of a domain whose domain controller is 
 using the system management server for software management.

 Now perform the following steps in the domain controller:

 --------------------------
   1.2.3.1 Package Creation
 --------------------------

  1. Create a shared folder on a network server (can be the same system as the 
     SMS 2.0 available in the domain) for the setup or any File Server 
     administrative installation point. This share folder will be the source 
     file location for the iKey Driver package.
  2. If the shared folder is on another system, map a network drive on the 
     system with SMS 2.0 setup and connect to the share created in step 1 above. 
  3. On the Start menu, click Run, and then run MSIEXEC /A IKEYDRVR.MSI from 
     the root of the iKey Driver CD. 
  4. Accept the end-user license agreement and then click Install. Setup 
     expands and copies the files from the iKey Driver CD to the administrative 
     installation point, extracts the compressed files, and creates a hierarchy 
     of folders in the root folder of the share. 

 ---------------------------------------------
   1.2.3.2 Create Software Distribution Object
 ---------------------------------------------
  1. Start the SMS Administrator console, and then double-click Site Database. 
  2. Expand the site database, select and right-click Packages, point to New, 
     and then click Package. 
  3. The Package Properties page is displayed; In the General tab, enter the 
     package name, version, publisher etc. Open the DataSource tab and check 
     "This package contains source files" option, selecting the source directory 
     as set in step 1 in section 1.2.3.1 above. Click Apply to save the settings 
     and close the dialog.
  4. Select the Distribution Points for this package. Right-click on the node to 
     select "New -> Distribution Points". Click on Next and select the required 
     distribution point from the available list in the "Copy Package" window. 
     Click on Finish.
  5. Select the Programs node under this package, right-click and select 
     New -> Programs to create a new program for this package. In the General 
     tab enter the Program name, command line as "msiexec /I IKEYDRVR.MSI 
     /qn to install the driver in the silent mode. In the Environment tab, 
     select "Only when a user is logged on" under Program can run option. Apply
     the settings and close the dialog.
  6. Click Finish to create the package named SafeNet iKey Driver v4.0.0.1011
     English.

 ----------------------------------------------------
   1.2.3.3 Create Advertisement to Deploy the Package
 ----------------------------------------------------

 To create an advertisement and assign SMS distribution points using the 
 Distribute Software Wizard:

  1. In the SMS Administrator console, navigate to Packages, right-click your 
     package, point to All Tasks, and then click Distribute Software. 
  2. On the Distribute Software Wizard page, click Next. 
  3. The Package page is displayed. Select the Distribute an existing package 
     check box, click SafeNet iKey Driver, and then click Next. 
  4. On the Distribution Points page, select the distribution points (for 
     example, "All Systems") you want for the SafeNet iKey Driver distribution, 
     and then click Next. 
  5. On the Advertise a Program page, click Yes, and then click Next. 
  6. On Select a Program to Advertise page, click the program that you want to 
     include in this advertisement, and then click Next. 
  7. On the Advertisement Target page, select the Advertise the program to an 
     existing collection option, click Browse to select a collection, click OK, 
     and then click Next. 
  8. On the Advertisement Name page, click Next. 
  9. On the Advertise to Sub collections page, select the appropriate option 
     (for example, "All Systems") and then click Next. 
 10. On the Advertisement Schedule page, select the appropriate schedule, and 
     determine whether you want the advertisement to expire. If you are using 
     the distribution points as resilient sources, select No. Also select the 
     "This advertisement never expires" check box, and then click Next. 
 11. On the Assign Program page, select the appropriate option (for example, 
     "All Systems") and then click Next. 
 12. On the Completing the Distribute Software Wizard page, verify the 
     information under Details, and then click Finish to start the distribution. 

 Once the above is done, verify on the client system that the advertisement for 
 deploying the software appears and the package is installed automatically. 
 Since SMS is based on a polling mechanism, the advertisement at the client 
 will not appear immediately; it may take 10 minutes in some cases. 

--------------------------------
 2.0 WHAT'S NEW IN THIS RELEASE?
--------------------------------

This release of the iKey Driver is a major release that contains the MSI based 
installer. The following features are new in this release:

 - Support for new iKey 4000 USB token.

 - MSI based installer.

 - Installation through Windows Group policy.

 - Installation through System Management Server.


Please refer to the Release Notes for more detailed information on what is new 
in this version of the iKey Driver release.

-----------------------------------
 2.1 Problems Fixed in This Release
-----------------------------------

v4.0.0.1014 Release fixes:

-  Task# 25730: Old ikey token bitmap exists in "select device" dialog if multiple tokens exists.

v4.0.0.1013 Release fixes:

- Incorporated new iKey logo.

v4.0.0.1012 Release fixes:

- iKey driver is supported on Windows Vista operating system.
- WT# 82696: Installed files are not same when MSI and IS installer are installed separately

v4.0.0.1011 Release fixes:

- Upgradation problem from (exe) to (msi).

v4.0.0.1010 Release fixes:

- WT# 82540:  No Digital Signature tab in installer file.
- WT# 82437:  Installation should detect if smart card services are installed.
- WT# 80592:  Error msg when try to install over existing installation.
- Reboot is not required on uninstallation of iKey Driver.

v4.0.0.1009 Release fixes:

- MSIEXEC Engine version upgraded to 2.0.

v4.0.0.0007 Release fixes:

- This release of iKey driver has signed driver binaries for all three supported Windows platforms, 
  namely Windows 2000, Windows XP and Windows 2003.

v4.0.0.0006 Release fixes:

- WT# 80489: Fixed "Fatal Error in installation" during uninstallation of iKeyDriver in case of presence of ikey 4000 in the system.
- WT# 80592: Installation of same MSI driver version gives "A newer version of the program ...." has been removed.

v4.0.0.0005 Release fixes:

- Included WHQLed Driver binaries
- WT# 80489: Fixed "Fatal Error in installation" during uninstallation of iKeyDriver in case of presence of ikey in the system.
- WT# 80592: Removed "\n\n" from the custom message.
- WT# 82140: Fixed "Philips Semiconductor Smart Card Reader is displayed as one of the reader when iKey driver is installed".
- WT# 82138: Fixed "Installation does not complete when requested to insert the token to finish installation".The installation finishes gracefully upon inserting the token as drivers are WHQLed.  

v4.0.0.0004 Release fixes:

- WT# 82118: Fixed rebranding related issue 
- Fixed issue related to GenerateSessionKey command APDU.

v4.0.0.0003 Release fixes:

 - Rebranding libraries to SafeNet
 - Added support for long APDUs (length of APDU command upto 1496 bytes, as per iKey 4000 specifications)

v4.0.0.0002 Release fixes:

 - No Onyx incidents are entertained in this release. 
   This release is to add support for new iKey 4000 USB token.

v3.4.9.1006 Release fixes:
 
 - The install no longer deletes the Smart Card Services

v3.4.8.1120 Release fixes:

 - Onyx incident #766817: Windows XP SP2 issue.

v3.4.7.1118 Release fixes:

 - CR # 70354: iKey 2032: problems with standby mode.
 - CR # 70591: iKey 2032 NonFIPS: problems with standby mode recovering on a 
               Compaq N610c laptop.

v3.4.6.1115 Release fixes:

 - CR # 69886:   iKey driver crashed while testing with DC2.exe available 
                 with HCT 11.2 tool.
 - CR # 66123:   iKey UI library : "iKey - Select Device" should have a token 
                 selected when the message appears
 - CR # 66324:   The shortcut for refresh (f5) in the token utility does not 
                 refresh the status of the token utility. 
 - CR # 66379:	  iKeyUI_DlgChangePIN returns PIN
 - CR # 69558:   Uninstall may not be clean for ikey 1000 installer.
 - CR # 69559:   Uninstall may not be clean for ikey 1000 installer.
 - CR # 69560:   Uninstall may not be clean for ikey 1000 installer.
 - CR # 69561:   uninstall may not be clean for ikey installer (AS, SDK and 
                 iKeyAll).
 - CR # 70002:   LED blinking stops for the selected token even if the non 
                 selected token is not connected.
 - CR # 70041:   iKey1000v222 SDK is not installable on Win98,ME,NT. 
 - CR # 70184:   iKey driver installation with invalid logpath option.
 - CR # 70186:   No of readers not reduced but increased on reinstallation.
 - CR # 70023:   After the upgrade installation, the uninstallation is not 
                 clean.


v3.4.5.1108 Release fixes:

 - CR # 68008:   Enhancement request for iKey driver installer to be in MSI 
                 format.  

------------------------------------------------------
 3.0 LATE-BREAKING INFORMATION
------------------------------------------------------

Go to SafeNet web site at http://www.safenet-inc.com for the most 
up-to-date product information.

---------------------
 4.0 Known Problems
---------------------
 - Under Windows XP/2003, uninstalling the iKey Driver after upgrading it to the 
   current version requires a reboot.
 
 - Under Windows XP/2003, for iKey 2000 SDK or iKey 2000 Authentication Solutions,
   the Start CIP on Boot option must be disabled. If you already have an 
   installation of iKey 2000 SDK or iKey 2000 Authentication Solution software 
   installed, and are upgrading the iKey Driver, perform the following steps to 
   disable the Start CIP on boot option:

	1. Open Control Panel.
	2. Select Switch to classic view.
	3. Open the Administrative Tools folder.
	4. Open the Services control panel applet.
	5. Select DkeyServ.
	6. For StartType, select Disabled.
	7. Restart your system.

   If you have not yet installed the iKey 2000 SDK or iKey 2000 Authentication
   Software, deselect the Start CIP on boot option when performing the 
   installation.

 - On all platforms, if a newer version of the iKey Driver is installed,
   and you install the iKey 2000 SDK or iKey 2000 Authentication Solutions
   software, the operating system may not be able to find the appropriate
   device driver upon installation of an iKey Security Token. In this case, 
   you must rerun the iKey Driver installation to repair the system.

 - When installing the iKey Components (iKeyAll.exe) version 2.6 through 
   version 3.1.x, if a newer version of the iKey Driver is already installed, 
   the iKey Components installer will fail to install. To resolve this issue 
   you must:

	1. Uninstall the iKey Driver.
	2. Install iKey Components.
	3. Re-install the iKey Driver.

Please refer to the Release Notes for more detailed information on known 
problems in this iKey Driver release.

-------------------------------------------------------
 5.0 REPORTING PROBLEMS
-------------------------------------------------------

If you find any problems while using the iKey Driver, please contact 
SafeNet Technical Support using any of the following methods:

===============================================
SafeNet, Inc. Customer Connection Center (C3)
http://c3.safenet-inc.com


Americas
=================================
Internet - http://www.safenet-inc.com/support/index.asp
E-mail - support@safenet-inc.com


United States
---------------------------------------------------------
Telephone - (800) 545-6608, (410) 931-7520 


Europe
=================================
E-mail - support@safenet-inc.com


France
---------------------------------------------------------
Telephone - 0825 341000


Germany
---------------------------------------------------------
Telephone - 01803 7246269


United Kingdom
---------------------------------------------------------
Telephone -  +44 (0) 1276 608000, +1 410 931-7520 (Intl)


Pacific Rim
=================================
E-mail - support@safenet-inc.com


Australia and New Zealand
---------------------------------------------------------

Telephone - +1 410 931-7520(Intl)


China
---------------------------------------------------------

Telephone - (86) 10 8851 9191


India
---------------------------------------------------------

Telephone - +1 410 931-7520 (Intl)


Taiwan and Southeast Asia
---------------------------------------------------------

Telephone - (886) 2 27353736,+1 410 931-7520 (Intl)


OTHER COUNTRIES
---------------
Customers not in countries listed above, please contact your local
distributor.


  
Readme.txt February 20, 2007, V.4.0.0.1014
