		iKey Driver Version 4.0.0.14
		README.TXT
		Copyright (c) 2007 SafeNet, Inc.
		All Rights Reserved.
---------------------------------------------------------------------------- 

Thank you for choosing the iKey Driver from SafeNet, Inc. 
The iKey Driver contains the drivers and libraries used for SafeNet's
iKey Security Tokens.

This README file provides information on product installation and 
uninstallation, new features, last-minute news and where to go  
for more information or to report problems.

-----------------------------
 Table of Contents
-----------------------------

1.0 Installing iKey Driver
    1.1 Compatibility
    1.2 Installation	
2.0 What's New in This Release?
    2.1 Problems Fixed in This Release
3.0 Late-Breaking News
4.0 Known Problems
5.0 Reporting Problems

----------------------------------------------------------
 1.0 INSTALLING IKEY DRIVER
----------------------------------------------------------

-----------------------------
 1.1 Compatibility
-----------------------------

IMPORTANT! Please read this section completely BEFORE running the
iKey Driver setup program to ensure that you are aware of any installation 
issues that may pertain to your system and environment.

 1. A Windows-based installation program is provided to 
    make installation of the iKey Driver quick and easy.
    The installation program runs only on the following operating
    systems:

    for iKeyDrvr.exe:

    - Windows 2000
    - Windows XP
    - Windows 2003    
    - Windows Vista

    All systems require a functional USB controller to be installed prior
    to installation of the iKey Driver.

 2. On Toshiba Model T440 CDX laptops, iKey Security Tokens will not 
     be recognized. This is due to an incompatibility with the USB 
     controller used in the iKey Security Tokens. Currently, there is no 
     known workaround for this issue.

 3. iKey 2000 SDK/Authentication Solution Software

    - When upgrading the iKey Components on a system with the iKey 2000 SDK 
      or iKey 2000 Authentication Solution software installed, you must restart 
      your system upon completion of the iKey Components installation. 
      This is required for the CIP service to see any new readers that may 
      have been created during iKey Components installation.

    - Under Windows XP/2003, the Start CIP on Boot option must be disabled for 
      version 4.5 or version 4.6 of iKey 2000 SDK or iKey 2000 Authentication 
      Solution software. If you already have an installation of iKey 2000 
      SDK or iKey 2000 Authentication Solution v4.5 or v4.6 software 
      installed, perform the following steps to disable the Start CIP on 
      boot option:

	1. Open Control Panel.
	2. Select Switch to classic view.
	3. Open the Administrative Tools folder.
	4. Open the Services control panel applet.
	5. Select DkeyServ.
	6. For StartType, select Disabled.
	7. Restart your system.

      If you have not yet installed the iKey 2000 SDK or iKey 2000 Authentication
      v4.5 or v4.6 software, deselect the Start CIP on boot option when 
      performing the installation.

    - On all platforms, if a newer version of the iKey Components is installed,
      and you install the iKey 2000 SDK or iKey 2000 Authentication Solutions
      software, the operating system may not be able to find the appropriate
      device driver upon installation of an iKey Security Token. In this case, 
      you must rerun the iKey Components installation to repair the system.

 4. iKey 1000 Components Installer (iKeyAll.exe)

    - When installing version 2.6 through version 3.1.x of the iKey Component 
      Installer, if a newer version of the iKey Driver is already installed,
      the iKey Components installer will fail to install any files. To 
      resolve this issue you must:

	1. Uninstall the iKey Driver.
	2. Install iKey Components.
	3. Re-install the iKey Driver.

 5. Windows 2000/XP/2003

    - When upgrading the driver from version 2.6 through 3.3, all iKey 
      Security Tokens must be removed PRIOR to installation. This prevents
      you from being logged off during the driver upgrade if you are
      using an iKey Security Token for Smart Card logon.

    - When upgrading the iKey Driver from version 3.3, you may be prompted
      by the system to restart your computer. Please click NO in ALL
      system restart message boxes until iKey Driver installation is complete. 
      Failure to do so may cause iKey Driver installation to fail. If this 
      occurs, rerun the setup program to repair the installation.

    - When upgrading the driver from version 2.6 through 3.3, error messages
      may exist in the System Event Log after installation. These error
      messages indicate that the installation could not create a unique reader
      name. This is by design and has no effect on the iKey Driver installation.

    - When uninstalling the iKey Driver, all iKey Security Tokens must 
      be removed PRIOR to uninstallation. This prevents you from being 
      logged off during driver uninstallation if you are using an iKey Security 
      Token for Smart Card logon.

    - When uninstalling version 2.6 through 3.3 of the driver, you must restart
      your system prior to installing this version of the driver.

 6. If you are planning to upgrade your operating system, uninstall the iKey 
     Driver BEFORE you perform the system upgrade. After you have
     upgraded your system, you can then re-install the iKey Driver.

 7. For Windows 2000 , Windows 2003, Windows Vista
    and Windows XP, installation of a iKey Security Token must be performed 
    per-USB port, per-USB hub.  

-----------------------------
 1.2 Installation
-----------------------------

The following instructions assume you are installing the iKey software 
using a CD, and  that you are installing from CD-ROM drive D. If a drive 
other than drive D is used,  substitute D: with the appropriate drive letter. 
(If installing from the Internet,  double-click the file you downloaded to 
start the installation process.)

 - Insert the CD into the CD-ROM drive.

 - If CD auto run is set, the installation should start. If not, from the 
   Start menu, select Run. The Run dialog box appears. Type D:\IKEYDRVR.EXE 
   at the Open prompt and click OK.
       
 - Follow the on-screen instructions to complete the installation. 
     
 - You can access this readme file from the 
   %SystemDrive%\Program Files\SafeNet\iKey Driver folder, where
   %SystemDrive% is the system drive letter of where Windows is installed. 

----------------------------------------------------------
 2.0 WHAT'S NEW IN THIS RELEASE?
----------------------------------------------------------

This release of the iKey Driver is for supporting iKey 4000.
The new iKey 4000 is based on SCCOS 3.0 (Model 400 Smart Card)

 - Unified driver for all the iKeys including 
   iKey 1000, iKey 1032, iKey 2000, iKey 2032 iKey 3000 and iKey 4000

 - iKey 4000 is currently supported on Windows 2003 Server, 
   Windows XP and Windows 2000

 - For Windows 2003, Windows 2000 and Windows XP, on a clean system, a system 
   reboot is not required to complete iKey Driver installation.

 - For Windows 95, Windows 98, Windows ME and Windows NT, 
   older version (1.20.20.70) of driver will get installed 

 - For Windows 98 and Windows ME, the driver can now be configured
   for either PC/SC support or non-PC/SC support.

 - For Windows 98, Windows ME and Windows NT 4.0, the driver can 
   now be installed on a clean system and not require a system reboot 
   if the application will be used without PC/SC support. Upon the next 
   system restart, the iKey Driver will be configured for PC/SC support.

 - iKey Driver installation can now repair the current installation,
   if corrupted. To repair your system, simply rerun the iKey Driver 
   setup program.

 - For Windows 2000/2003 and XP, the iKey Driver will now, upon resume from
   standby, power-up iKey 2000 and iKey 3000 tokens.

Please refer to the Release Notes for more detailed information on 
what is new in this version of the iKey Driver release.

-----------------------------
 2.1 Problems Fixed in This Release
-----------------------------

v4.0.0.14 Release fixes:

-  Task# 25730: Old ikey token bitmap exists in "select device" dialog if multiple tokens exists.

v4.0.0.13 Release fixes:

- Incorporated new iKey logo.

v4.0.0.12 Release fixes:

- This release of iKey driver supports Windows platforms, 
  namely Windows 2000, Windows XP, Windows 2003 and Windows Vista.
- WT# 82719: Driver binary file is prompted continously after uninstalling upgraded driver.
- WT# 82718: Upgrade from "3." series driver still displays Rainbow Technologies in Driver details.
- WT# 82696: Installed files are not same when MSI and IS installer are installed separately

v4.0.0.11 Release fixes:

- Upgradation problem from (exe) to (msi).

v4.0.0.10 Release fixes:

- WT# 82540:  No Digital Signature tab in installer file.
- WT# 82437:  Installation should detect if smart card services are installed.
- Reboot is not required on uninstallation of iKey Driver.
- Installation problem in Windows 2000.

v4.0.0.9 Release fixes:

- This release of iKey driver has signed driver binaries for all three supported Windows platforms, 
  namely Windows 2000, Windows XP and Windows 2003.

v4.0.0.1 Release Fixes:
 - No CR was included in this release. 
 - This release is to add support for new iKey 4000 USB token.

v3.4.9.6 Release fixes:
 
 - The install no longer deletes the Smart Card Services

v3.4.8.120 Release fixes:

 - Onyx incident #766817: Windows XP SP2 issue.

v3.4.7.118 Release fixes:

 - CR # 70354: iKey 2032: problems with standby mode.
 - CR # 70591: iKey 2032 NonFIPS: problems with standby mode recovering on a 
                 Compaq N610c laptop.

v3.4.6.115 Release fixes:

 - CR # 69886:   iKey driver crashed while testing with DC2.exe available 
                 with HCT 11.2 tool.
 - CR # 66123:   iKey UI library : "iKey - Select Device" should have a 
                 token selected when the message appears.
 - CR # 66378:   The OK Button is disabled even if the token other than 
                 the selected token is removed. 
 - CR # 66379:   iKeyUI_DlgChangePIN returns PIN.
 - CR # 69558:   Uninstall may not be clean for iKey 1000 installer.
 - CR # 69559:   Uninstall may not be clean for iKey 1000 installer.
 - CR # 69560:   Uninstall may not be clean for iKey 1000 installer.
 - CR # 69561:   uninstall may not be clean for iKey installer (AS, SDK and
                 iKeyAll).
 - CR # 70002:   LED blinking stops for the selected token even if the non
                 selected token is disconnected.
 - CR # 70041:   iKey1000v222 SDK is not installable on Win98,ME,NT. 
 - CR # 70184:   iKey driver installation with invalid logpath option.
 - CR # 70186:   No of readers not reduced but increased on reinstallation.
 - CR # 70023:   After the upgrade installation, the uninstallation is not 
                 clean.
                 	
v3.4.5.108 Release fixes:

 - CR # 68721:   Win2k: Error in inf file causes WHQL test to fail
 - CR # 68634:   Win2k: Uninstalling a unsigned driver causes blue screen
 - CR # 68588:   Win2K: Token not accessible if removed after suspend and 
                        reinserted during resume.

v3.4.4.103 Release fixes:

 - CR # 67992:   When Hotfix 814033 is installed, the iKey driver installer 
                 fails.

v3.4.3.102 Release fixes:

 - CR # 67558:   If the number of readers specified is less than one, then 
                 the driver creates 32 readers.
 - CR # 67556:   The command line option "ikeydrvr -a HIDE_UI_OPTS=96 
                 READERS=10 LogPath=c:\ /s " cannot install the driver.
 - CR # 67537:   Readme file does not show the proper installation regarding the 
                        usage of the installer.
 - CR # 67774:   The Windows 98 uninstaller will set the SourcePath key to 
                 the Windows subdirectory, instead of deleting the registry 
                 key.
 - CR # 67992:   When Hotfix 814033 is installed, the iKey driver installer
                 fails.

v3.4.2 Release fixes:

 - CR # 67159:   When reinstalling the iKey Driver 3.4.1, the read me file is
                 always shown.
 - CR # 67160:   Need option for iKey Driver installer to not create/or 
                 delete short cuts for OEM install. 
 - CR # 67161:   Platform specific builds of iKey Driver installer to 
                 reduce size.
 - CR # 67477:   XP: Cannot locate iKey if scardsrv -reinstall was performed.
 - CR # 67211:   iKeyDrvr: Microsoft Hotfix Q328145 applied to W2K, WinXP 
                 invalidates SafeNet's digitally signed driver.
 - CR # 67488:   98/ME:Cannot find device after fresh install w/o reboot and 
                 app running before key inserted.
 - CR # 66380:   Attempt to set empty token name for second consecutive
                 time returns RB_FILE_NOT_FOUND error.
 - CR # 66463:   The maximum number of files accepts negative values while 
                 creating a new directory.

v3.4.1 Release fixes:

 - CR # 66401:   IKEY1000: Open specific by serial no. failed on a second 
                 token when the first token was in used by another 
                 application.
 - CR # 66474:   Installation fails with "INF Section not found" under 
                 Windows 2000 or Windows XP.

v3.4.0 Release fixes:

 - CR # 62867:   iKey API library keeps access privileges after closing a
                              device.
 - CR # 63599:   iKey API library IKEY_CHANGE_NO_HASH not taken into
                              account.
 - CR # 63700:   SafeNet VR driver and Aladdin software together causes
                              crash under NT4.
 - CR # 63849:   iKey API library does not report correct driver version.
 - CR # 63954:   iKey API library does not report correct driver version 
                              under Windows 95.
 - CR # 64346:   VR sometimes fails to load at boot time.
 - CR # 64639:   Found New Hardware message not displayed after 
                              installation.
 - CR # 64642:   Smart Card Logo not displayed after reboot.
 - CR # 64662:   Wrong version number displayed in Add/Remove Programs.
 - CR # 64663:   Program hangs when token is being unplugged and 
                              plugged back in or switched with another token.
 - CR # 64664:   Token not recognized. Requires reboot.
 - CR # 64673:   iKey not recognized after initialization.
 - CR # 64675:   iKey not recognized by the Utility Application.
 - CR # 64744:   Information message displayed in the event viewer.
 - CR # 64883:   Communication to iKey driver sometimes failed on iKey 3000
                              smart card (AET).
 - CR # 64893:   Installer v3.3.0 Build 34 Reboot Problem.
 - CR # 64894:   "Installshield Wizard" is intermittently running forever.
 - CR # 64895:   Error extracting support files (driver v3.3.0 build 34).
 - CR # 64934:   The VR driver (version 3.3) prevents Standby mode from 
                 working.
 - CR # 64948:   Driver crash if device removed while operation pending.
 - CR # 64952:   Error 800900D occurred while generating certificate request
                 in Win98.
 - CR # 64967:   Removing token on W2K system caused blue screen (core dump).
 - CR # 65042:   Token not recognized during logon.
 - CR # 65043:   iKey Driver - RNBTOKEN.SYS crashed on XP.
 - CR # 65047:   iKey Driver - iKey 1000 crashed on XP.
 - CR # 65050:   iKey 2032 ATR string for PC/SC has 1 byte that is wrong.
 - CR # 65051:   iKey 1000 ATR string for PC/SC is only setup for v0.7 of 
                 firmware.
 - CR # 65052:   ikey_GenRandom only returns max of 60 bytes of random data.
 - CR # 65053:   Bad context handle causes trap in library 1000/2000.
 - CR # 65054:   Autodetect driver logic in library can cause VR readers 
                             not to be created.
 - CR # 65055:   Driver installation does not set Scard Service to Automatic 
                 under XP/Win2000.
 - CR # 65056:   Removing driver under NT 4.0 with PC/SC causes service 
                 error.
 - CR # 65057:   NT 4.0 Driver fails to recognize iKey Token.
 - CR # 65058:   NT 4.0 Driver hangs when performing RSA key generation.
 - CR # 65095:   Incorrect version for iKey token driver.
 - CR # 65096:   System crash during uninstallation of iKey Driver version 
                 3.3.1.
 - CR # 65097:   Updating from iKey driver v 3.3.0 to 3.3.1 causes system to 
                              prompt for reboot in the middle of installation.
 - CR # 65229:   Driver does not install smoothly with iKey plugged in during
                              installation.
 - CR # 65403:   Error message "String UNINSTALL_COMPLETE_STATUS is not found" 
                 appears when uninstalling the driver.
 - CR # 65405:   Driver installer parameter -s -a /s does not work.
 - CR # 65406:   Turning off VR on Win2K by manually changing registry 
                              does not work.
 - CR # 65407:   Status bar stays at 0% for a while when installing the iKey 
                              driver.
 - CR # 65408:   Windows 2000 takes 20-30 seconds to boot-up after 
                 uninstalling the driver.
 - CR # 65429:   iKey 2000 Token Utilities hangs with driver in non-PC/SC 
                 mode and 2 iKeys inserted.
 - CR # 65438:   On Win 98, system unable to install driver when iKey 2000 
                              series token is inserted after reinstalling iKey driver.
 - CR # 65987:   iKey 2000/2032 switches from VR to USB mode when 
                              unplugged and re-inserted.
 - CR # 65401:   Quick remove and reinsert the iKeys on Windows 2000 will 
                              cause the system not to recognize the iKeys.
 - CR # 65620:   Windows XP: Driver Verifier rnbtoken.sys: find1k, 
                              find2k cannot find ikey1000, ikey2000
 - CR # 65622:   Windows 98 and Windows Me: Unplug iKey 1000 freezes 
                              system (WHQL interops 3 usb hubs, misc devices).

------------------------------------------------------
 3.0 LATE-BREAKING INFORMATION
------------------------------------------------------

Go to SafeNet web site at http://www.safenet-inc.com for the most 
up-to-date product information.

---------------------
 4.0 Known Problems
---------------------

 - Under Windows 98 and Windows ME, If another vendor's smart card reader is
   already installed, the iKey Driver will be configured to run in non-PC/SC 
   mode. This avoids compatibility issues with some vendors' PC/SC smart 
   card reader drivers on these platforms.

 - Under Windows NT 4.0, installed applications and/or smart card
   readers that use the PC/SC environment may remove, upon
   uninstallation, the SMCLIB.SYS file from the 
   %SystemRoot%\System32\Drivers directory. 

  This file is required by the iKey Device Driver and can cause a system 
  trap if removed. As a result, SafeNet recommends you 
  do the following:
 
     1.  Uninstall the iKey Driver.
     2.  Uninstall the PC/SC applications and/or smart card reader drivers. 
     3.  Re-install the iKey Driver. 

  This will prevent an uninstall program from removing this file and 
  causing a system trap.

 - Under Windows XP/2003, for iKey 2000 SDK or iKey 2000 Authentication Solutions,
   the Start CIP on Boot option must be disabled. If you already have an 
   installation of iKey 2000 SDK or iKey 2000 Authentication Solution 
   software installed, and are  upgrading the iKey Driver, perform the 
   following steps to disable the Start CIP on boot option:

	1. Open Control Panel.
	2. Select Switch to classic view.
	3. Open the Administrative Tools folder.
	4. Open the Services control panel applet.
	5. Select DkeyServ.
      6. For StartType, select Disabled.
	7. Restart your system.

   If you have not yet installed the iKey 2000 SDK or iKey 2000 Authentication
   Software, deselect the Start CIP on boot option when performing the 
   installation.

 - Under Windows NT 4.0, Windows 2000/2003 and Windows XP, when uninstalling 
   version 2.6 through 3.3 of the driver, you must restart
   your system prior to installing this version of the driver.

 - On all platforms, if a newer version of the iKey Driver is installed,
   and you install the iKey 2000 SDK or iKey 2000 Authentication Solution
   software, the operating system may not be able to find the appropriate
   device driver upon installation of an iKey Security Token. In this case, 
   you must rerun the iKey Driver installation to repair the system.

 - When installing the iKey Components (iKeyAll.exe) version 2.6 through 
   version 3.1.x, if a newer version of the iKey Driver is already 
   installed, the iKey Components installer will fail to install. To resolve
   this issue you must:

	1. Uninstall the iKey Driver.
	2. Install iKey Components.
	3. Re-install the iKey Driver.

Please refer to the Release Notes for more detailed information on known 
problems in this iKey Driver release.

-------------------------------------------------------
 5.0 REPORTING PROBLEMS
-------------------------------------------------------

If you find any problems while using the iKey Driver, please contact 
SafeNet Technical Support using any of the following methods:

===============================================
SafeNet, Inc. Customer Connection Center (C3)
http://c3.safenet-inc.com


Americas
=================================
Internet - http://www.safenet-inc.com/support/index.asp
E-mail - support@safenet-inc.com


United States
---------------------------------------------------------
Telephone - (800) 545-6608, (410) 931-7520 


Europe
=================================
E-mail - support@safenet-inc.com


France
---------------------------------------------------------
Telephone - 0825 341000


Germany
---------------------------------------------------------
Telephone - 01803 7246269


United Kingdom
---------------------------------------------------------
Telephone -  +44 (0) 1276 608000, +1 410 931-7520 (Intl)


Pacific Rim
=================================
E-mail - support@safenet-inc.com


Australia and New Zealand
---------------------------------------------------------

Telephone - +1 410 931-7520(Intl)


China
---------------------------------------------------------

Telephone - (86) 10 8851 9191


India
---------------------------------------------------------

Telephone - +1 410 931-7520 (Intl)


Taiwan and Southeast Asia
---------------------------------------------------------

Telephone - (886) 2 27353736,+1 410 931-7520 (Intl)


OTHER COUNTRIES
---------------
Customers not in countries listed above, please contact your local
distributor.

 
 
Readme.txt February 20, 2007, V. 4.0.0.14
