//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
  TStringGrid *StringGrid1;
  void __fastcall FormShow(TObject *Sender);
  
  void __fastcall StringGrid1DrawCell(TObject *Sender, int Col, int Row,
          TRect &Rect, TGridDrawState State);
  void __fastcall StringGrid1MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
private:	// User declarations
  int SelectedCol;
  TFont* HeaderFont;
  TFont* CellFont;
  TFont* RowTitleFont;
public:		// User declarations
  __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
