//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
  : TForm(Owner)
{
  HeaderFont=new TFont;
  HeaderFont->Name="Arial";
  HeaderFont->Style = HeaderFont->Style << fsBold;

  RowTitleFont=new TFont;
  RowTitleFont->Name="Times New Roman";
  RowTitleFont->Style = RowTitleFont->Style << fsBold;


  CellFont=new TFont;   //default font is ms sans serif

}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormShow(TObject *Sender)
{
 //size grid
 StringGrid1->RowCount=20;
 StringGrid1->ColCount=20;

 //put stuff in the grid
 for (int i=0;i<StringGrid1->RowCount;i++)
   for (int j=0;j<StringGrid1->ColCount;j++)
      StringGrid1->Cells[j][i]="R"+IntToStr(i)+"C"+IntToStr(j);

 //select the first column
 SelectedCol=1;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::StringGrid1DrawCell(TObject *Sender, int Col,
      int Row, TRect &Rect, TGridDrawState State)
{
 TColor textColor,backColor;
 if (Col==SelectedCol)
  {
   //this is a cell in a selected row
   backColor=clNavy;
   textColor=clWhite;
  }
 else
  {
   //this is a cell in a non-selected row
   backColor=clWhite;

   if (Row%2 == 0)
     textColor=clBlack;
   else
     textColor=clGreen;

  }


 //fill the rectangle with the selected color
 StringGrid1->Canvas->Brush->Color=backColor;
 StringGrid1->Canvas->FillRect(Rect);

 //draw the contents of the cell
 if (Row == 0)
  {
   //this is a column header - draw the text centered and in Arial bold
   int leftMargin=(Rect.Right-Rect.Left-StringGrid1->Canvas->TextWidth(StringGrid1->Cells[Col][Row]))/2;
   StringGrid1->Canvas->Font->Assign(HeaderFont);
   StringGrid1->Canvas->Font->Color=textColor;
   StringGrid1->Canvas->TextOut(Rect.Left+leftMargin,Rect.Top+2,StringGrid1->Cells[Col][Row]);
   StringGrid1->Canvas->Font->Assign(CellFont);
  }
 else if (Col == 0)
  {
   //this is a row title - draw the text centered and in Times new roman bold
   int leftMargin=(Rect.Right-Rect.Left-StringGrid1->Canvas->TextWidth(StringGrid1->Cells[Col][Row]))/2;
   StringGrid1->Canvas->Font->Assign(RowTitleFont);
   StringGrid1->Canvas->Font->Color=textColor;
   StringGrid1->Canvas->TextOut(Rect.Left+leftMargin,Rect.Top+2,StringGrid1->Cells[Col][Row]);
   StringGrid1->Canvas->Font->Assign(CellFont);
  }
 else
  {
   //all other rows are left justified
   StringGrid1->Canvas->Font->Color=textColor;
   StringGrid1->Canvas->TextOut(Rect.Left+2,Rect.Top+2,StringGrid1->Cells[Col][Row]);
  }


}
//---------------------------------------------------------------------------
void __fastcall TForm1::StringGrid1MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
 //find out which cell was clicked
 int row,col;
 StringGrid1->MouseToCell(X,Y,col,row);

 //select that column
 SelectedCol=col;

 //now redraw the entire grid
 StringGrid1->Refresh();
}
//---------------------------------------------------------------------------
