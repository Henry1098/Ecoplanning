//---------------------------------------------------------------------------

#ifndef Uasg10H
#define Uasg10H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "AdvGrid.hpp"
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <ImgList.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TLabel *Label2;
        TAdvStringGrid *AdvStringGrid1;
        TImageList *ImageList1;
        TTimer *Timer1;
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall AdvStringGrid1ScrollHint(TObject *Sender, int ARow,
          AnsiString &hintstr);
        void __fastcall Timer1Timer(TObject *Sender);
private:	// User declarations
public:		// User declarations
        AnsiString feat[10];
        int featidx;
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
