//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Uasg10.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "AdvGrid"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  int i;

  AdvStringGrid1->Delimiter = ';';
  AdvStringGrid1->SaveFixedCells = false;
  AdvStringGrid1->LoadFromCSV("CARS.CSV");
  AdvStringGrid1->AutoNumberCol(0);
  AdvStringGrid1->AutoSizeColumns(true,5);

  AdvStringGrid1->Cells[1][0]="Car";
  AdvStringGrid1->Cells[2][0]="Type";
  AdvStringGrid1->Cells[3][0]="Cc";
  AdvStringGrid1->Cells[4][0]="Pk";
  AdvStringGrid1->Cells[5][0]="Cylinder";
  AdvStringGrid1->Cells[6][0]="Kw";
  AdvStringGrid1->Cells[7][0]="Price";
  AdvStringGrid1->Cells[8][0]="Country";

  for (i=1; i<AdvStringGrid1->RowCount; i++)
   AdvStringGrid1->AddDataImage(8,i,0,haBeforeText,vaTop);

  AdvStringGrid1->RichEdit->Text = "Car list";
  AdvStringGrid1->RichEdit->SelStart = 0;
  AdvStringGrid1->RichEdit->SelLength = 3;
  AdvStringGrid1->RichEdit->SelAttributes->Color = clRed;
  AdvStringGrid1->RichEdit->SelAttributes->Style =
    AdvStringGrid1->RichEdit->SelAttributes->Style << fsBold;
  AdvStringGrid1->RichEdit->SelStart = 4;
  AdvStringGrid1->RichEdit->SelLength = 4;
  AdvStringGrid1->RichEdit->SelAttributes->Color = clBlue;
  AdvStringGrid1->RichEdit->SelAttributes->Style =
    AdvStringGrid1->RichEdit->SelAttributes->Style << fsItalic;
  AdvStringGrid1->RichToCell(0,0,AdvStringGrid1->RichEdit);
  AdvStringGrid1->FixedColWidth=64;

  feat[1]="Selectable grid wallpaper";
  feat[2]="Glyphs to indicate ascending/descending sort";
  feat[3]="Easy rich text display with exposed Richedit control";
  feat[4]="Dynamic vertical scroll hinting";
  feat[5]="New data dependent image type";
  feat[6]="Incremental key search in sorted column";
  featidx=1;

 AdvStringGrid1->SortColumn = 1;
 AdvStringGrid1->SortDirection = sdAscending;
 AdvStringGrid1->QSort();

}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1ScrollHint(TObject *Sender, int ARow,
      AnsiString &hintstr)
{
   hintstr = AdvStringGrid1->Cells[1][ARow] + " " + AdvStringGrid1->Cells[2][ARow];
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
 featidx++;
 if (featidx==7) featidx=1;
 Label2->Caption = feat[featidx];

}
//---------------------------------------------------------------------------
