//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Uasg11.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "AdvGrid"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  int i;
  int j;


  AdvStringGrid1->SaveFixedCells = FALSE;
  AdvStringGrid1->LoadFromCSV("CARS.CSV");
  AdvStringGrid1->AutoSizeColumns(TRUE,10);

  i=1;
  j=1;

  while (i < AdvStringGrid1->RowCount - 1)
  {
    if (AdvStringGrid1->Cells[1][j] == "BMW")
      bmwnode = j;

    while ((AdvStringGrid1->Cells[1][j]==AdvStringGrid1->Cells[1][j+1]) & (j < AdvStringGrid1->RowCount - 1))
    {
      j++;
    }
    if (i != j) AdvStringGrid1->AddNode(i,j-i+1);
    i=j+1;
    j=i;
  }

  AdvStringGrid1->FixedCols = 0;
  AdvStringGrid1->Row = 1;
  AdvStringGrid1->Col = 1;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::RadioGroup1Click(TObject *Sender)
{
 switch (RadioGroup1->ItemIndex)
 {
 case 0:AdvStringGrid1->CellNode->NodeType=cnFlat;
        break;
 case 1:AdvStringGrid1->CellNode->NodeType=cn3D;
        break;
 case 2:AdvStringGrid1->CellNode->NodeType=cnGlyph;
        break;
 }

}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
   AdvStringGrid1->ExpandAll();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
   AdvStringGrid1->ContractAll();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
   AdvStringGrid1->ExpandNode(bmwnode);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button4Click(TObject *Sender)
{
   AdvStringGrid1->ContractNode(bmwnode);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1ContractNode(TObject *Sender,
      int ARow, int ARowreal)
{
  ListBox1->Items->Add("Contract : " + IntToStr(ARow) + "-" + IntToStr(ARowreal));
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1ExpandNode(TObject *Sender, int ARow,
      int ARowreal)
{
  ListBox1->Items->Add("Expand : " + IntToStr(ARow) + "-" + IntToStr(ARowreal));
}
//---------------------------------------------------------------------------
