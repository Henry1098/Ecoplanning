//---------------------------------------------------------------------------

#ifndef Uasg11H
#define Uasg11H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "AdvGrid.hpp"
#include <ExtCtrls.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TAdvStringGrid *AdvStringGrid1;
        TRadioGroup *RadioGroup1;
        TButton *Button1;
        TButton *Button2;
        TListBox *ListBox1;
        TButton *Button3;
        TButton *Button4;
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall RadioGroup1Click(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall Button3Click(TObject *Sender);
        void __fastcall Button4Click(TObject *Sender);
        void __fastcall AdvStringGrid1ContractNode(TObject *Sender,
          int ARow, int ARowreal);
        void __fastcall AdvStringGrid1ExpandNode(TObject *Sender, int ARow,
          int ARowreal);
private:	// User declarations
public:		// User declarations
        int bmwnode;
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
