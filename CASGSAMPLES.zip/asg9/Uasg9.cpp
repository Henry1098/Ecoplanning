//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Uasg9.h"
#include "uasgprev.h"
#include "graphics.hpp"
#include <math.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "AdvGrid"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  AdvStringGrid1->SaveFixedCells = FALSE;
  AdvStringGrid1->LoadFromCSV("TEST.CSV");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
  TAsgPrev *AsgPrev;
  AsgPrev = new TAsgPrev(Form1);
  AsgPrev->Asg = AdvStringGrid1;
  AsgPrev->ShowModal();
  AsgPrev->Free();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::AdvStringGrid1PrintPage(TObject *Sender,
      TCanvas *Canvas, int pagenr, int pagexsize, int pageysize)
{
  Graphics::TBitmap *bmp;
  TRect r;
  double ratio;

  bmp = new Graphics::TBitmap();

  bmp->LoadFromFile("ATHENA.BMP");

  ratio = bmp->Width/bmp->Height;

  r.Left = AdvStringGrid1->PrintColOffset[1];
  r.Top = 0;
  r.Right = r.Left + floor(AdvStringGrid1->PrintSettings->HeaderSize*ratio);
  r.Bottom = r.Top - AdvStringGrid1->PrintSettings->HeaderSize;

  Canvas->StretchDraw(r,bmp);

  bmp->Free();

  r.Left = r.Right;
  r.Top = 0;
  Canvas->TextOut(r.Left,r.Top,"Printed with TAdvStringGrid");
  r.Top = r.Top - Canvas->TextHeight("gh");
  Canvas->TextOut(r.Left,r.Top,"showing how to add a bitmap in the header");

  r.Left = AdvStringGrid1->PrintColOffset[1];
  r.Right = AdvStringGrid1->PrintColOffset[8];

  r.Top = -AdvStringGrid1->PrintSettings->HeaderSize+2;
  Canvas->MoveTo(r.Left,r.Top);
  Canvas->LineTo(r.Right,r.Top);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
  AdvStringGrid1->Print();        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::CheckBox1Click(TObject *Sender)
{
  AdvStringGrid1->PrintSettings->Centered = CheckBox1->Checked;        
}
//---------------------------------------------------------------------------

