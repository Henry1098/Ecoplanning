//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Uasg5.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "AdvGrid"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1GetEditorType(TObject *Sender,
      int ACol, int ARow, TEditorType &aEditor)
{
  AnsiString fn;

  switch (ACol)
  {
  case 1: aEditor = edComboList;
          AdvStringGrid1->ClearComboString();
          if (FileExists("cars.dat"))
            AdvStringGrid1->Combobox->Items->LoadFromFile("cars.dat");
          break;
  case 2: aEditor = edComboList;
          AdvStringGrid1->ClearComboString();
          if (AdvStringGrid1->Cells[1][ARow] != "")
          {
            fn = LowerCase(AdvStringGrid1->Cells[1][ARow]) + ".dat";

            if (FileExists(fn))
            {
             AdvStringGrid1->Combobox->Items->LoadFromFile(fn);
            }
          }
          break;
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  int i;
  for (i = 0; i < 2; i++)
    AdvStringGrid1->AddImageIdx(i,0,i,haBeforeText,vaTop);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1ComboChange(TObject *Sender,
      int ACol, int ARow, int AItemIndex, AnsiString ASelection)
{
  TStringList *sl;
  AnsiString fn;
  if (ACol == 1)
  {
    sl = new TStringList;

    fn = LowerCase(ASelection) + ".dat";
    if (FileExists(fn))
      sl->LoadFromFile(fn);

    if (sl->Count > 0)
      AdvStringGrid1->Cells[2][ARow] = sl->Strings[0];

    sl->Free();
  }

}
//---------------------------------------------------------------------------
