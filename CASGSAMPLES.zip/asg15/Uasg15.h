//---------------------------------------------------------------------------

#ifndef Uasg15H
#define Uasg15H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "AdvGrid.hpp"
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
#include <Grids.hpp>
#include <ImgList.hpp>
#include <ToolWin.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TButton *Ok;
        TButton *Cancel;
        TToolBar *ToolBar1;
        TComboBox *Fontname;
        TComboBox *FontSize;
        TToolButton *ToolButton17;
        TToolButton *BoldButton;
        TToolButton *ItalicButton;
        TToolButton *UnderlineButton;
        TToolButton *LeftAlign;
        TToolButton *CenterAlign;
        TToolButton *RightAlign;
        TToolButton *BulletsButton;
        TToolButton *ToolButton1;
        TToolButton *Superscript;
        TToolButton *Subscript;
        TToolButton *ToolButton2;
        TToolButton *ToolButton3;
        TRichEdit *RTFControl;
        TAdvStringGrid *AdvStringGrid1;
        TButton *Button1;
        TButton *Button2;
        TCheckBox *CheckBox1;
        TImageList *ImageList1;
        TColorDialog *ColorDialog1;
        void __fastcall BoldButtonClick(TObject *Sender);
        void __fastcall ItalicButtonClick(TObject *Sender);
        void __fastcall UnderlineButtonClick(TObject *Sender);
        void __fastcall LeftAlignClick(TObject *Sender);
        void __fastcall CenterAlignClick(TObject *Sender);
        void __fastcall RightAlignClick(TObject *Sender);
        void __fastcall BulletsButtonClick(TObject *Sender);
        void __fastcall ToolButton1Click(TObject *Sender);
        void __fastcall SubscriptClick(TObject *Sender);
        void __fastcall SuperscriptClick(TObject *Sender);
        void __fastcall ToolButton2Click(TObject *Sender);
        void __fastcall ToolButton3Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FontnameChange(TObject *Sender);
        void __fastcall FontSizeChange(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall OkClick(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall RTFControlSelectionChange(TObject *Sender);
private:	// User declarations
public:		// User declarations
        int __fastcall GetOffset(void);
        void __fastcall  SetOffset(int offs);
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
