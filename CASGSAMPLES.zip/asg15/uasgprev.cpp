//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "uasgprev.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAsgPrev *AsgPrev;
//---------------------------------------------------------------------------
__fastcall TAsgPrev::TAsgPrev(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TAsgPrev::PaintBox1Paint(TObject *Sender)
{
  Asg->PrintPreview(PaintBox1->Canvas,PaintBox1->ClientRect);
}
//---------------------------------------------------------------------------
