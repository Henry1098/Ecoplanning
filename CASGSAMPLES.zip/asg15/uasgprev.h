//---------------------------------------------------------------------------

#ifndef uasgprevH
#define uasgprevH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include "advgrid.hpp"

//---------------------------------------------------------------------------
class TAsgPrev : public TForm
{
__published:	// IDE-managed Components
        TPaintBox *PaintBox1;
        void __fastcall PaintBox1Paint(TObject *Sender);
private:	// User declarations
public:		// User declarations
        TAdvStringGrid *Asg;
        __fastcall TAsgPrev(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TAsgPrev *AsgPrev;
//---------------------------------------------------------------------------
#endif
