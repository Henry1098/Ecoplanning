//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Uasg15.h"
#include "uasgprev.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "AdvGrid"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

int __fastcall TForm1::GetOffset(void)
{
  TCharFormat format;

  format.cbSize = sizeof(format);
  format.dwMask = CFM_OFFSET;

  SendMessage(RTFControl->Handle,EM_GETCHARFORMAT, SCF_SELECTION,int(&format));

  return (format.yOffset);
}

void __fastcall TForm1::SetOffset(int offs)
{
  TCharFormat format;
  format.cbSize = sizeof(format);
  format.dwMask = CFM_OFFSET;
  format.yOffset = offs;
  SendMessage(RTFControl->Handle,EM_SETCHARFORMAT, SCF_SELECTION,int(&format));
}

void __fastcall TForm1::BoldButtonClick(TObject *Sender)
{
 if (BoldButton->Down)
  RTFControl->SelAttributes->Style = RTFControl->SelAttributes->Style << fsBold;
 else
  RTFControl->SelAttributes->Style = RTFControl->SelAttributes->Style >> fsBold;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ItalicButtonClick(TObject *Sender)
{
 if (ItalicButton->Down)
  RTFControl->SelAttributes->Style = RTFControl->SelAttributes->Style << fsItalic;
 else
  RTFControl->SelAttributes->Style = RTFControl->SelAttributes->Style >> fsItalic;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::UnderlineButtonClick(TObject *Sender)
{
 if (UnderlineButton->Down)
  RTFControl->SelAttributes->Style = RTFControl->SelAttributes->Style << fsUnderline;
 else
  RTFControl->SelAttributes->Style = RTFControl->SelAttributes->Style >> fsUnderline;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::LeftAlignClick(TObject *Sender)
{
  RTFControl->Paragraph->Alignment = taLeftJustify;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::CenterAlignClick(TObject *Sender)
{
  RTFControl->Paragraph->Alignment = taCenter;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::RightAlignClick(TObject *Sender)
{
  RTFControl->Paragraph->Alignment = taRightJustify;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::BulletsButtonClick(TObject *Sender)
{
 RTFControl->Paragraph->LeftIndent = 10;
 RTFControl->Paragraph->Numbering = TNumberingStyle(BulletsButton->Down);

}
//---------------------------------------------------------------------------
void __fastcall TForm1::ToolButton1Click(TObject *Sender)
{
  ColorDialog1->Color = RTFControl->SelAttributes->Color;
  if (ColorDialog1->Execute())
    RTFControl->SelAttributes->Color = ColorDialog1->Color;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::SubscriptClick(TObject *Sender)
{
 if (Subscript->Down)
   SetOffset(-40);
 else
   SetOffset(0);

 Superscript->Down = FALSE;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SuperscriptClick(TObject *Sender)
{
 if (Superscript->Down)
   SetOffset(40);
 else
   SetOffset(0);

 Subscript->Down = FALSE;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ToolButton2Click(TObject *Sender)
{
 if (RTFControl->Paragraph->FirstIndent >= 10)
   RTFControl->Paragraph->FirstIndent = RTFControl->Paragraph->FirstIndent-10;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ToolButton3Click(TObject *Sender)
{
 RTFControl->Paragraph->FirstIndent = RTFControl->Paragraph->FirstIndent+10;        
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  AdvStringGrid1->RichEdit->Text ="Rich text";
  AdvStringGrid1->RichEdit->SelStart=0;
  AdvStringGrid1->RichEdit->SelLength=4;
  AdvStringGrid1->RichEdit->SelAttributes->Color=clRed;
  AdvStringGrid1->RichEdit->SelAttributes->Style =
    AdvStringGrid1->RichEdit->SelAttributes->Style << fsBold;
  AdvStringGrid1->RichEdit->SelStart=5;
  AdvStringGrid1->RichEdit->SelLength=4;
  AdvStringGrid1->RichEdit->SelAttributes->Color=clBlue;
  AdvStringGrid1->RichEdit->SelAttributes->Style =
    AdvStringGrid1->RichEdit->SelAttributes->Style << fsItalic;
  AdvStringGrid1->RichToCell(0,1,AdvStringGrid1->RichEdit);

  AdvStringGrid1->RichEdit->SelAttributes->Style =
    AdvStringGrid1->RichEdit->SelAttributes->Style >> fsItalic >> fsBold;

  AdvStringGrid1->RichEdit->Clear();

  AdvStringGrid1->RichEdit->SelAttributes->Color = clBlack;

  AdvStringGrid1->RichEdit->Text="Superscript";

  AdvStringGrid1->RichEdit->SelStart=0;
  AdvStringGrid1->RichEdit->SelLength=5;
  AdvStringGrid1->RichEdit->SelSuperscript();
  AdvStringGrid1->RichEdit->SelAttributes->Color = clBlue;

  AdvStringGrid1->RichToCell(0,2,AdvStringGrid1->RichEdit);

  AdvStringGrid1->RichEdit->Clear();
  AdvStringGrid1->RichEdit->SelAttributes->Color=clBlack;

  AdvStringGrid1->RichEdit->Text="Subscript";
  AdvStringGrid1->RichEdit->SelStart=0;
  AdvStringGrid1->RichEdit->SelLength=3;
  AdvStringGrid1->RichEdit->SelSubscript();
  AdvStringGrid1->RichEdit->SelAttributes->Color=clBlue;

  AdvStringGrid1->RichToCell(0,3,AdvStringGrid1->RichEdit);

  AdvStringGrid1->RichEdit->Clear();
  AdvStringGrid1->RichEdit->SelAttributes->Color=clBlack;
  AdvStringGrid1->RichEdit->SelNormal();

  AdvStringGrid1->RichEdit->Text="One\x00DTwo\x00DThree";
  AdvStringGrid1->RichEdit->Paragraph->Numbering = nsBullet;

  AdvStringGrid1->RichToCell(0,4,AdvStringGrid1->RichEdit);

  AdvStringGrid1->AutoSizeRows(FALSE,4);
  AdvStringGrid1->ArrowColor=clRed;


}
//---------------------------------------------------------------------------
void __fastcall TForm1::FontnameChange(TObject *Sender)
{
  RTFControl->SelAttributes->Name = Fontname->Items->Strings[Fontname->ItemIndex];
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FontSizeChange(TObject *Sender)
{
 int i;
 i = StrToInt(FontSize->Text);

 RTFControl->SelAttributes->Size = i;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
  AdvStringGrid1->Print();        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::OkClick(TObject *Sender)
{
  Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
  TAsgPrev *AsgPrev;

  AsgPrev = new TAsgPrev(Form1);
  AsgPrev->Asg = AdvStringGrid1;

  AsgPrev->ShowModal();

  AsgPrev->Free();

}
//---------------------------------------------------------------------------

void __fastcall TForm1::RTFControlSelectionChange(TObject *Sender)
{
 BoldButton->Down = RTFControl->SelAttributes->Style.Contains(fsBold);
 ItalicButton->Down = RTFControl->SelAttributes->Style.Contains(fsItalic);
 UnderlineButton->Down = RTFControl->SelAttributes->Style.Contains(fsUnderline);
 BulletsButton->Down = Boolean(RTFControl->Paragraph->Numbering);
 FontSize->Text = IntToStr(RTFControl->SelAttributes->Size);
 Fontname->Text = RTFControl->SelAttributes->Name;

 switch (RTFControl->Paragraph->Alignment)
 {
 taLeftJustify: LeftAlign->Down = True;
                break;
 taRightJustify: RightAlign->Down = True;
                 break;
 taCenter: CenterAlign->Down = True;
           break;
 }

 if (GetOffset()<0)
  {
    Superscript->Down = FALSE;
    Subscript->Down = TRUE;
  }
 if (GetOffset()==0)
  {
    Superscript->Down = FALSE;
    Subscript->Down = FALSE;
  }
 if (GetOffset()>0)
  {
    Superscript->Down = TRUE;
    Subscript->Down = FALSE;
  }
}
//---------------------------------------------------------------------------

