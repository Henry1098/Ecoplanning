//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Uasg22.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "AdvGrid"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
 AdvStringGrid1->SaveFixedCells = FALSE;
 AdvStringGrid1->LoadFromCSV("CARS.CSV");
 AdvStringGrid1->RowCount = AdvStringGrid1->RowCount + 1;
 AdvStringGrid1->FixedFooters =1;
 AdvStringGrid1->FixedAsButtons = TRUE;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
  int i;
  bool added;
  TFilterData *fd;

  added = FALSE;
  AdvStringGrid1->Filter->Clear();
  AdvStringGrid1->FilterActive = FALSE;

  for(i = AdvStringGrid1->FixedCols; i< AdvStringGrid1->ColCount; i++)
  {
   if (AdvStringGrid1->Cells[i][0] != "")
   {
     fd = AdvStringGrid1->Filter->Add();

     fd->Condition = AdvStringGrid1->Cells[i][0];
     fd->Column = i;
     added = TRUE;
   }
  }
  if (added)
   AdvStringGrid1->FilterActive = TRUE;

 if (!added)
   ShowMessage("No filter conditions set");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1ClickCell(TObject *Sender, int ARow,
      int ACol)
{
  AnsiString s;

  if ((ARow == 0) & (ACol > 0))
  {
    s = AdvStringGrid1->Cells[ACol][ARow];

    if (InputQuery("Column " + IntToStr(ACol),"Condition",s))
      AdvStringGrid1->Cells[ACol][ARow] = s;
    else
      AdvStringGrid1->RepaintCell(ACol,ARow);
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
  int i;
  for(i = AdvStringGrid1->FixedCols; i< AdvStringGrid1->ColCount - 1; i++)
  {
    AdvStringGrid1->Cells[i][0] = "";
  }
  AdvStringGrid1->Filter->Clear();
  AdvStringGrid1->FilterActive = FALSE;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
  AdvStringGrid1->Cells[1][0]=">B & <M";
  AdvStringGrid1->Cells[3][0]=">5000";
  AdvStringGrid1->Cells[8][0]="4";
  Button1Click(Sender);
}
//---------------------------------------------------------------------------
