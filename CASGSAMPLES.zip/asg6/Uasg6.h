//---------------------------------------------------------------------------

#ifndef Uasg6H
#define Uasg6H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "AdvGrid.hpp"
#include <Grids.hpp>
#include <ImgList.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TAdvStringGrid *AdvStringGrid1;
        TButton *Button1;
        TCheckBox *CheckBox1;
        TCheckBox *CheckBox2;
        TButton *Button2;
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall LoadDir(void);
        void __fastcall FindDataToGrid(int row, _WIN32_FIND_DATAA lpData);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall AdvStringGrid1CanSort(TObject *Sender, int ACol,
          bool &DoSort);
        void __fastcall AdvStringGrid1CustomCompare(TObject *Sender,
          AnsiString str1, AnsiString str2, int &Res);
        void __fastcall AdvStringGrid1GetAlignment(TObject *Sender,
          int ARow, int ACol, TAlignment &AAlignment);
        void __fastcall AdvStringGrid1GetFormat(TObject *Sender, int ACol,
          TSortStyle &AStyle, AnsiString &aPrefix, AnsiString &aSuffix);
private:	// User declarations
public:		// User declarations


        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
