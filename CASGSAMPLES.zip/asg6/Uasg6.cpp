//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Uasg6.h"
#include "ShellApi.h"
#include "math.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "AdvGrid"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
  AdvStringGrid1->ClearNormalCells();
  AdvStringGrid1->RowCount = 2;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  SHFILEINFO ShFileInfo;

  AdvStringGrid1->GridImages =  new TImageList(Form1);
  AdvStringGrid1->GridImages->Height = 16;
  AdvStringGrid1->GridImages->Width = 16;
  AdvStringGrid1->GridImages->ShareImages = True;
  AdvStringGrid1->GridImages->BkColor = clNone;
  AdvStringGrid1->GridImages->Masked = False;
  AdvStringGrid1->GridImages->Handle = SHGetFileInfo(0,0,&ShFileInfo, sizeof(ShFileInfo),
    SHGFI_SMALLICON || SHGFI_ICON || SHGFI_SYSICONINDEX);

  AdvStringGrid1->SortColumn = 1;

}

void __fastcall TForm1::FindDataToGrid(int row, _WIN32_FIND_DATAA lpData)
{
  _SYSTEMTIME systime;
  SHFILEINFO shfileinfo;
  int ret;
  char FileName[255];

  AdvStringGrid1->Cells[1][row] = lpData.cFileName;

  if ((CheckBox1->Checked) || (lpData.nFileSizeLow < 1024))
    AdvStringGrid1->Cells[2][row] = IntToStr(lpData.nFileSizeLow);
  else
    {
    ret = floor(lpData.nFileSizeLow/1024);
    AdvStringGrid1->Cells[2][row] = IntToStr(ret) + "Kb";
    }

  FileTimeToSystemTime(&lpData.ftLastAccessTime,&systime);

  AdvStringGrid1->Cells[4][row] = DateToStr(EncodeDate(systime.wYear,systime.wMonth,systime.wDay));

  ret = SHGetFileInfo(lpData.cFileName,0,&shfileinfo,sizeof(shfileinfo),
                      SHGFI_TYPENAME || SHGFI_SYSICONINDEX);

  AdvStringGrid1->Cells[3][row] = shfileinfo.szTypeName;

  AdvStringGrid1->AddImageIdx(0,row,shfileinfo.iIcon ,haLeft,vaTop);

  row++;

  if (row >= AdvStringGrid1->RowCount)
    AdvStringGrid1->RowCount = row + 1;
}

void __fastcall TForm1::LoadDir(void)
{
  _WIN32_FIND_DATAA lpFindFileData;
  HANDLE FindHandle;
  int i;
  AnsiString dir;

  AdvStringGrid1->ClearNormalCells();
  AdvStringGrid1->RowCount = 2;
  i = 1;

  dir = GetCurrentDir();

  FindHandle = FindFirstFile("*.*",&lpFindFileData);

  if (FindHandle != 0)
  {
    FindDataToGrid(AdvStringGrid1->RowCount-1, lpFindFileData);
    while (FindNextFile(FindHandle,&lpFindFileData))
    {
     FindDataToGrid(AdvStringGrid1->RowCount-1,lpFindFileData);
    }
  }
  AdvStringGrid1->RowCount = AdvStringGrid1->RowCount - 1;
  AdvStringGrid1->AutoSizeColumns(False,16);
}


//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
  LoadDir();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::AdvStringGrid1CanSort(TObject *Sender, int ACol,
      bool &DoSort)
{
   DoSort = ACol > 0;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::AdvStringGrid1CustomCompare(TObject *Sender,
      AnsiString str1, AnsiString str2, int &Res)
{
  int i1;
  int i2;

  if ( str1.Pos("Kb") > 0)
  {
    str1.Delete(str1.Pos("Kb") ,2);
    i1 = StrToInt(str1);
    i1 = i1 * 1024;
  }
  else
  {
    i1 = StrToInt(str1);
  }

  if ( str2.Pos("Kb") > 0)
  {
    str2.Delete(str2.Pos("Kb") ,2);
    i2 = StrToInt(str2);
    i2 = i2 * 1024;
  }
  else
  {
    i2 = StrToInt(str2);
  }

  if (i1 == i2)
    Res = 0;
  else
  {
    if (i1 > i2)
      Res = 1;
    else
      Res = -1;
  }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::AdvStringGrid1GetAlignment(TObject *Sender,
      int ARow, int ACol, TAlignment &AAlignment)
{
  if (ACol == 2)
    AAlignment = taRightJustify;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::AdvStringGrid1GetFormat(TObject *Sender, int ACol,
      TSortStyle &AStyle, AnsiString &aPrefix, AnsiString &aSuffix)
{
  switch (ACol)
  {
  case 1,3:if (CheckBox2->Checked)
        AStyle = ssAlphabetic;
      else
        AStyle = ssAlphaNoCase;
      break;
  case 2:if (!CheckBox1->Checked)
      AStyle = ssCustom;
    else
      AStyle = ssNumeric;
      break;
  case 4: AStyle = ssDate;
          break;
  }

}
//---------------------------------------------------------------------------

