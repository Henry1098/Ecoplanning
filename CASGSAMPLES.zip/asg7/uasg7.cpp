//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "uasg7.h"
//---------------------------------------------------------------------------
#pragma link "AdvGrid"
#pragma link "Grids"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  AdvStringGrid1->SaveFixedCells = FALSE;
  AdvStringGrid1->LoadFromCSV("sample.csv");
  AdvStringGrid1->AutoSizeColumns(FALSE,8);
  AdvStringGrid1->AutoSizeRows(FALSE,8);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1GetCellColor(TObject *Sender, int ARow,
	int ACol, TGridDrawState AState, TBrush *ABrush, TFont *AFont)
{
  if ((ACol==0) & (ARow>0))
  {
   ABrush->Color = clYellow;
   AFont->Color = clRed;
   AFont->Style = AFont->Style << fsBold;
  }

  if ((ACol==2) & (ARow>0))
  {
   if (AdvStringGrid1->Cells[ACol][ARow]=="4") AFont->Color=clGreen;
   if (AdvStringGrid1->Cells[ACol][ARow]=="6") AFont->Color=clBlue;
   if (AdvStringGrid1->Cells[ACol][ARow]=="8") AFont->Color=clBlack;
   if (AdvStringGrid1->Cells[ACol][ARow]=="12") AFont->Color=clRed;
  }

}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1GetFormat(TObject *Sender, int ACol,
	TSortStyle &AStyle, AnsiString &aPrefix, AnsiString &aSuffix)
{
 switch(ACol) {
 case 0: AStyle=ssAlphaNoCase;
         break;
 case 1: AStyle=ssAlphaNoCase;
         break;
 case 2: AStyle=ssNumeric;
         break;
 case 3: AStyle=ssDate;
         break;
 case 4: AStyle=ssNumeric;
         aSuffix="pk";
         break;
 case 5: AStyle=ssNumeric;
         aPrefix="$";
         break;
 }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::AdvStringGrid1GetAlignment(TObject *Sender, int ARow,
	int ACol, TAlignment &AAlignment)
{
 switch(ACol) {
 case 1: AAlignment=taCenter;
         break;
 case 2,4: AAlignment=taRightJustify;
           break;

 }

}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1GridHint(TObject *Sender, int Arow,
	int Acol, AnsiString &hintstr)
{
 switch(Acol) {
 case 0: hintstr="Car manufacturer";
         break;
 case 1: hintstr="Car model";
         break;
 case 2: hintstr="Nr. of cylinders in model";
         break;
 case 3: hintstr="Introduction date";
         break;
 case 4: hintstr="Engine horse power";
         break;
 case 5: hintstr="Date of production start";
         break;
 case 6: hintstr="Link to manufacturer website";
         break;
 }


}
//---------------------------------------------------------------------------
