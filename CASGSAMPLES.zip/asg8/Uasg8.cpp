//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Uasg8.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "AdvGrid"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SavetoCSV1Click(TObject *Sender)
{
  if (OpenDialog1->Execute()) 
    AdvStringGrid1->LoadFromCSV(OpenDialog1->FileName);

}
//---------------------------------------------------------------------------
void __fastcall TForm1::LoadfromCSV1Click(TObject *Sender)
{
 if (SaveDialog1->Execute())
 {
   AdvStringGrid1->SaveToCSV(SaveDialog1->FileName);
 }

}
//---------------------------------------------------------------------------

int __stdcall  EnumFontsProc(TLogFont &LogFont, TTextMetric &TextMetric, int FontType, TStrings &Data)
{
  Data.Add(LogFont.lfFaceName);
  return(1);
}


void __fastcall TForm1::FormCreate(TObject *Sender)
{
  TStrings *st;
  HDC DC;
  DC = GetDC(0);

  st = FontName->Items;

 // EnumFonts(DC, NULL, EnumFontsProc, &st);

  ReleaseDC(0, DC);
  FontName->Sorted = True;
  FontName->ItemIndex = FontName->Items->IndexOf("Arial");
  FontSize->ItemIndex=1;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton4Click(TObject *Sender)
{
  ColorDialog1->Color = RichEdit1->SelAttributes->Color;

  if (ColorDialog1->Execute())
    RichEdit1->SelAttributes->Color = ColorDialog1->Color;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton1Click(TObject *Sender)
{
 if (RichEdit1->SelAttributes->Style.Contains(fsBold))
   RichEdit1->SelAttributes->Style =
     RichEdit1->SelAttributes->Style >> fsBold;
 else
   RichEdit1->SelAttributes->Style =
     RichEdit1->SelAttributes->Style << fsBold;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton2Click(TObject *Sender)
{
 if (RichEdit1->SelAttributes->Style.Contains(fsItalic))
   RichEdit1->SelAttributes->Style =
     RichEdit1->SelAttributes->Style >> fsItalic;
 else
   RichEdit1->SelAttributes->Style =
     RichEdit1->SelAttributes->Style << fsItalic;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton3Click(TObject *Sender)
{
 if (RichEdit1->SelAttributes->Style.Contains(fsUnderline))
   RichEdit1->SelAttributes->Style =
     RichEdit1->SelAttributes->Style >> fsUnderline;
 else
   RichEdit1->SelAttributes->Style =
     RichEdit1->SelAttributes->Style << fsUnderline;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton6Click(TObject *Sender)
{
   RichEdit1->Paragraph->Alignment=taLeftJustify;      
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton7Click(TObject *Sender)
{
   RichEdit1->Paragraph->Alignment=taCenter;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton5Click(TObject *Sender)
{
   RichEdit1->Paragraph->Alignment=taRightJustify;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton8Click(TObject *Sender)
{
  AdvStringGrid1->RichToCell(AdvStringGrid1->Col,AdvStringGrid1->Row,RichEdit1);
  AdvStringGrid1->HideSelection();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1SelectCell(TObject *Sender, int ACol,
      int ARow, bool &CanSelect)
{
  AdvStringGrid1->CellToRich(ACol,ARow,RichEdit1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FontNameChange(TObject *Sender)
{
  RichEdit1->SelAttributes->Name = FontName->Items->Strings[FontName->ItemIndex];
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FontSizeChange(TObject *Sender)
{
  RichEdit1->SelAttributes->Size = StrToInt(FontSize->Items->Strings[FontSize->ItemIndex]);
}
//---------------------------------------------------------------------------
