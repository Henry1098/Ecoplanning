//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Uasg12.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "AdvGrid"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  int i;

  AdvStringGrid1->Cells[0][1] = "10525";

  radopt1 = new TStringList();
  radopt1->Add("Delphi");
  radopt1->Add("C++Builder");
  radopt1->Add("JBuilder");

  radopt2 = new TStringList();
  radopt2->Add("Std");
  radopt2->Add("Prof");
  radopt2->Add("C/S");

  for(i=1 ; i< AdvStringGrid1->RowCount - 1;i++)
  {
    AdvStringGrid1->AddRadio(1,i,0,-1,radopt1);
    AdvStringGrid1->AddRadio(2,i,1,-1,radopt2);
  }

}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1RadioClick(TObject *Sender, int ACol,
      int ARow, int AIdx)
{
 TMemoryStream *ms;

 ms = new TMemoryStream();

 AdvStringGrid1->SaveToStream(ms);
 ms->Position=0;
 AdvStringGrid2->LoadFromStream(ms);
 ms->Free();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid2GetEditorType(TObject *Sender,
      int ACol, int ARow, TEditorType &aEditor)
{
 if ((ACol == 1) | (ACol == 2))
   aEditor=edComboList;

 if (ACol == 1)
   AdvStringGrid2->Combobox->Items->Assign(radopt1);
 if (ACol == 2)
   AdvStringGrid2->Combobox->Items->Assign(radopt2);

}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid2CellValidate(TObject *Sender,
      int Col, int Row, AnsiString &Value, bool &Valid)
{
 TMemoryStream *ms;

 ms = new TMemoryStream();

 AdvStringGrid2->SaveToStream(ms);
 ms->Position=0;
 AdvStringGrid1->LoadFromStream(ms);
 ms->Free();

}
//---------------------------------------------------------------------------
