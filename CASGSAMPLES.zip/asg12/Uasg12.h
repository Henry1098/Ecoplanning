//---------------------------------------------------------------------------

#ifndef Uasg12H
#define Uasg12H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "AdvGrid.hpp"
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TAdvStringGrid *AdvStringGrid1;
        TAdvStringGrid *AdvStringGrid2;
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall AdvStringGrid1RadioClick(TObject *Sender, int ACol,
          int ARow, int AIdx);
        void __fastcall AdvStringGrid2GetEditorType(TObject *Sender,
          int ACol, int ARow, TEditorType &aEditor);
        void __fastcall AdvStringGrid2CellValidate(TObject *Sender,
          int Col, int Row, AnsiString &Value, bool &Valid);
private:	// User declarations
public:		// User declarations
        TStringList *radopt1;
        TStringList *radopt2;
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
