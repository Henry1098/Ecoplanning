//---------------------------------------------------------------------------

#ifndef Uasg3H
#define Uasg3H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "AdvGrid.hpp"
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TLabel *Label2;
        TAdvStringGrid *AdvStringGrid1;
        void __fastcall AdvStringGrid1AutoInsertRow(TObject *Sender,
          int ARow);
        void __fastcall AdvStringGrid1GetEditMask(TObject *Sender,
          int ACol, int ARow, AnsiString &Value);
        void __fastcall AdvStringGrid1AutoAddRow(TObject *Sender,
          int ARow);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
