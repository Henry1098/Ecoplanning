//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Uasg3.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "AdvGrid"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm1::AdvStringGrid1AutoInsertRow(TObject *Sender,
      int ARow)
{
  int i;

  if ((AdvStringGrid1->Cells[0][ARow - 1] != "") & (ARow > 1))
    i = AdvStringGrid1->Ints[0][ARow - 1];
  else
    i = 0;

  AdvStringGrid1->Cells[0][ARow] = IntToStr(i + 1);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::AdvStringGrid1GetEditMask(TObject *Sender,
      int ACol, int ARow, AnsiString &Value)
{
  switch (ACol)
  {
  case 0: Value = "!000;1;_";
          break;
  case 1: Value = "";
          break;
  case 2: Value = "!000;1;_";
          break;
  case 3: Value = "!99/99/00;1;_";
          break;
  case 4: Value = "!90:00;1;_";
          break;
  }

}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1AutoAddRow(TObject *Sender, int ARow)
{
  AdvStringGrid1AutoInsertRow(Sender,ARow);
}
//---------------------------------------------------------------------------
