//---------------------------------------------------------------------------

#ifndef Uasg16H
#define Uasg16H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "AdvGrid.hpp"
#include "asgprev.hpp"
#include "asgprint.hpp"
#include <Dialogs.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TButton *Button1;
        TAdvStringGrid *AdvStringGrid1;
        TButton *Button2;
        TAdvPreviewDialog *AdvPreviewDialog1;
        TAdvGridPrintSettingsDialog *AdvGridPrintSettingsDialog1;
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
