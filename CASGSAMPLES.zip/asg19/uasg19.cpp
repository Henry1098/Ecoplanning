//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "uasg19.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "AdvGrid"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
 AdvStringGrid1->Cells[1][1] = "100�A";
 AdvStringGrid1->Cells[1][2] = "50mA";
 AdvStringGrid1->Cells[1][3] = "3A";

 AdvStringGrid1->Cells[2][1] = "60$";
 AdvStringGrid1->Cells[2][2] = "45�";
 AdvStringGrid1->Cells[2][3] = "100EU";

}
//---------------------------------------------------------------------------

void __fastcall TForm1::AdvStringGrid1GetEditorType(TObject *Sender,
      int aCol, int aRow, TEditorType &aEditor)
{
 if (aCol==1)
  {
   AdvStringGrid1->BtnUnitEdit->Units->Clear();
   AdvStringGrid1->BtnUnitEdit->Units->Add("�A");
   AdvStringGrid1->BtnUnitEdit->Units->Add("mA");
   AdvStringGrid1->BtnUnitEdit->Units->Add("A");
   aEditor = edUnitEditBtn;
  }
 if (aCol==2)
  {
   AdvStringGrid1->BtnUnitEdit->Units->Clear();
   AdvStringGrid1->BtnUnitEdit->Units->Add("$");
   AdvStringGrid1->BtnUnitEdit->Units->Add("�");
   AdvStringGrid1->BtnUnitEdit->Units->Add("EU");
   aEditor = edUnitEditBtn;
  }


}
//---------------------------------------------------------------------------
