//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Uasg20.h"
#include <math.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "AdvGrid"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
 int i;
 int j;
 for (i=AdvStringGrid1->FixedRows; i < AdvStringGrid1->RowCount;i++)
 {
  for( j=AdvStringGrid1->FixedCols; j < AdvStringGrid1->ColCount;j++)
  {
    AdvStringGrid1->Cells[j][i]="<IMG src=\x022idx:"+IntToStr(int(floor(fmod(i+j,3))))+"\x022>This is <FONT color=""clred"">cell</FONT> <B>["+IntToStr(j)+":"+IntToStr(i)+"]</B>";
  }
 }
 AdvStringGrid1->AutoSizeColumns(FALSE,10);
 AdvStringGrid1->AutoNumberCol(0);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::AdvStringGrid1MouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
 int c;
 int r;
 AdvStringGrid1->MouseToCell(X,Y,c,r);
 if ((c>=0) & (r>=0))
   StatusBar1->SimpleText = AdvStringGrid1->StrippedCells[c][r];
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1GetFormat(TObject *Sender, int ACol,
      TSortStyle &AStyle, AnsiString &aPrefix, AnsiString &aSuffix)
{
 if (CheckBox1->Checked)
   AStyle = ssAlphabetic;
 else
   AStyle = ssHTML;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1CanSort(TObject *Sender, int ACol,
      bool &DoSort)
{
 AdvStringGrid1->Cursor = crHourGlass;        
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1ClickSort(TObject *Sender, int ACol)
{
 AdvStringGrid1->Cursor = crDefault;
}
//---------------------------------------------------------------------------
