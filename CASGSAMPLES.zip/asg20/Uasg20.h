//---------------------------------------------------------------------------

#ifndef Uasg20H
#define Uasg20H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "AdvGrid.hpp"
#include <ComCtrls.hpp>
#include <Grids.hpp>
#include <ImgList.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TAdvStringGrid *AdvStringGrid1;
        TStatusBar *StatusBar1;
        TCheckBox *CheckBox1;
        TImageList *ImageList1;
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall AdvStringGrid1MouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall AdvStringGrid1GetFormat(TObject *Sender, int ACol,
          TSortStyle &AStyle, AnsiString &aPrefix, AnsiString &aSuffix);
        void __fastcall AdvStringGrid1CanSort(TObject *Sender, int ACol,
          bool &DoSort);
        void __fastcall AdvStringGrid1ClickSort(TObject *Sender, int ACol);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
