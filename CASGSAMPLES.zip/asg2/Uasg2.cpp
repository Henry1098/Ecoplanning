//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Uasg2.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "AdvGrid"
#pragma link "CGRID"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1GetCellColor(TObject *Sender,
      int ARow, int ACol, TGridDrawState AState, TBrush *ABrush,
      TFont *AFont)
{
  if (AdvStringGrid1->Cells[ACol][ARow] != "")
  {
    if (AdvStringGrid1->Ints[ACol][ARow] < 0)
    {
      ABrush->Color = CColorGrid2->BackgroundColor;
      AFont->Color = CColorGrid2->ForegroundColor;
    }
    else
    {
      ABrush->Color = CColorGrid1->BackgroundColor;
      AFont->Color = CColorGrid1->ForegroundColor;
      AFont->Style = AFont->Style << fsBold;
    }
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
  int i;
  int j;

  for( i = 1; i < AdvStringGrid1->RowCount - 1; i++)
  {
    for (j = 1; j < AdvStringGrid1->ColCount - 1;j++)
    {
     AdvStringGrid1->Ints[j][i] = random(1000)-500;
    }
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::CColorGrid1Change(TObject *Sender)
{
  AdvStringGrid1->Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  Button1Click(Sender);
}
//---------------------------------------------------------------------------
