//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Uasg18.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "AdvGrid"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  AdvStringGrid1->SaveFixedCells = FALSE;
  AdvStringGrid1->LoadFromCSV("CARS.CSV");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::sortgroupClick(TObject *Sender)
{
 switch (sortgroup->ItemIndex)
 {
 case 0: AdvStringGrid1->QSort();
         break;
 case 1: AdvStringGrid1->SortIndexes->Clear();
         AdvStringGrid1->SortIndexes->Add(5);
         AdvStringGrid1->SortIndexes->Add(7);
         AdvStringGrid1->SortIndexes->Add(1);
         AdvStringGrid1->QSortIndexed();
         break;
 case 2: AdvStringGrid1->SortIndexes->Clear();
         AdvStringGrid1->SortIndexes->Add(4);
         AdvStringGrid1->SortIndexes->Add(6);
         AdvStringGrid1->SortIndexes->Add(3);
         AdvStringGrid1->QSortIndexed();
         break;
 case 3: AdvStringGrid1->SortIndexes->Clear();
         AdvStringGrid1->SortIndexes->Add(3);
         AdvStringGrid1->SortIndexes->Add(7);
         AdvStringGrid1->SortIndexes->Add(1);
         AdvStringGrid1->QSortIndexed();
         break;
 }

}
//---------------------------------------------------------------------------
