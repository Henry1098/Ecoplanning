//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("asg1.res");
USEFORM("Uasg1.cpp", Form1);
USEFORM("uasgprev.cpp", AsgPrev);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TForm1), &Form1);
                 Application->CreateForm(__classid(TAsgPrev), &AsgPrev);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
