//---------------------------------------------------------------------------

#include <vcl.h>
#include "math.h"
#pragma hdrstop

#include "Uasg1.h"
#include "Uasgprev.h"

#include "advgrid.hpp"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "AdvGrid"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::saveClick(TObject *Sender)
{
  AdvStringGrid1->SaveToFile("ADRES.TBL");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::loadClick(TObject *Sender)
{
  AdvStringGrid1->LoadFromFile("ADRES.TBL");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  AdvStringGrid1->LoadFromFile("ADRES.TBL");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button4Click(TObject *Sender)
{
  TPrintSettings *ps;

  ps = AdvStringGrid1->PrintSettings;

  ps->FixedHeight = 10 * StrToInt(Edit2->Text);
  ps->LeftSize = StrToInt(Edit3->Text)*10;
  ps->HeaderSize = StrToInt(Edit4->Text)*10;
  if (CheckBox1->Checked)
    ps->Borders = pbSingle;
  else
    ps->Borders = pbNoborder;

  AdvStringGrid1->Print();
}

//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1PrintNewPage(TObject *Sender,
      int ARow, bool &newpage)
{
  int i;
  int j;

  i = StrToInt(labelspage->Text);
  j = floor(fmod(ARow,i));

  if ((ARow > 0) & (j == 0))
    newpage = True;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1PrintSetColumnWidth(TObject *Sender,
      int ACol, int &Width)
{
  Width = StrToInt(Edit1->Text) * 10;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
  TAsgPrev *AsgPrev;

  TPrintSettings *ps;

  ps = AdvStringGrid1->PrintSettings;

  ps->FixedHeight = 10 * StrToInt(Edit2->Text);
  ps->LeftSize = StrToInt(Edit3->Text)*10;
  ps->HeaderSize = StrToInt(Edit4->Text)*10;
  if (CheckBox1->Checked)
    ps->Borders = pbSingle;
  else
    ps->Borders = pbNoborder;


  AsgPrev = new TAsgPrev(Form1);
  AsgPrev->Asg = AdvStringGrid1;

  AsgPrev->ShowModal();

  AsgPrev->Free();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button5Click(TObject *Sender)
{
  if (FontDialog1->Execute())
  {
    AdvStringGrid1->Font = FontDialog1->Font;
    AdvStringGrid1->PrintSettings->Font = FontDialog1->Font;
  }
}
//---------------------------------------------------------------------------
