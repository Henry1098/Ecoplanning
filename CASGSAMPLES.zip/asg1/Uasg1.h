//---------------------------------------------------------------------------

#ifndef Uasg1H
#define Uasg1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "AdvGrid.hpp"
#include <Dialogs.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label6;
        TLabel *Label7;
        TLabel *Label8;
        TLabel *Label9;
        TLabel *Label10;
        TLabel *Label11;
        TAdvStringGrid *AdvStringGrid1;
        TButton *save;
        TButton *load;
        TEdit *Edit1;
        TEdit *Edit2;
        TEdit *Edit3;
        TEdit *Edit4;
        TButton *Button3;
        TButton *Button4;
        TButton *Button5;
        TCheckBox *CheckBox1;
        TEdit *labelspage;
        TFontDialog *FontDialog1;
        void __fastcall saveClick(TObject *Sender);
        void __fastcall loadClick(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall Button4Click(TObject *Sender);
        void __fastcall AdvStringGrid1PrintNewPage(TObject *Sender,
          int ARow, bool &newpage);
        void __fastcall AdvStringGrid1PrintSetColumnWidth(TObject *Sender,
          int ACol, int &Width);
        void __fastcall Button3Click(TObject *Sender);
        void __fastcall Button5Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
