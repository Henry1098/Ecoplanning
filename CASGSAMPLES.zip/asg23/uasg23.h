//---------------------------------------------------------------------------

#ifndef uasg23H
#define uasg23H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "AdvGrid.hpp"
#include "asgprev.hpp"
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <FileCtrl.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TAdvStringGrid *AdvStringGrid1;
        TProgressBar *ProgressBar1;
        TPanel *Panel1;
        TLabel *Label1;
        TDriveComboBox *DriveComboBox1;
        TDirectoryListBox *DirectoryListBox1;
        TFileListBox *FileListBox1;
        TButton *Button1;
        TCheckBox *filenames;
        TUpDown *UpDown1;
        TAdvPreviewDialog *AdvPreviewDialog1;
        void __fastcall DirectoryListBox1Change(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall UpDown1Click(TObject *Sender, TUDBtnType Button);
        void __fastcall AdvStringGrid1GetAlignment(TObject *Sender,
          int ARow, int ACol, TAlignment &AAlignment);
private:	// User declarations
public:		// User declarations
        void __fastcall LoadImages(void);
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
