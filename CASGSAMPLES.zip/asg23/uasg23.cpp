//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "uasg23.h"


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "AdvGrid"
#pragma link "asgprev"
#pragma link "jpeg"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::LoadImages(void)
{
  int i;
  int c;
  int r;
  AnsiString dirpath;

  dirpath = DirectoryListBox1->Directory + "\\";

  i = FileListBox1->Items->Count;

  if (i <= 0)
    return;

  AdvStringGrid1->Clear();

  r = 1;
  c = 1;

  ProgressBar1->Min = 1;
  ProgressBar1->Max = FileListBox1->Items->Count;
  ProgressBar1->Position = 1;
  AdvStringGrid1->BeginUpdate();

  for(i = 1; i < FileListBox1->Items->Count; i++)
  {
   if (filenames->Checked)
   {
    AdvStringGrid1->Cells[c][r] = FileListBox1->Items->Strings[i - 1];
    AdvStringGrid1->CreateFilePicture(c,r,true,ShrinkWithAspectRatio,20,haCenter,vaAboveText)->Filename =
      (dirpath + FileListBox1->Items->Strings[i-1]);
   }
   else
   {
    AdvStringGrid1->CreateFilePicture(c,r,true,ShrinkWithAspectRatio,20,haCenter,vaCenter)->Filename =
      (dirpath + FileListBox1->Items->Strings[i-1]);
   }

   c++;

   if (c == AdvStringGrid1->ColCount)
   {
     c = 1;
     r++;
   }
   if (r == AdvStringGrid1->RowCount)
   {
     AdvStringGrid1->RowCount = AdvStringGrid1->RowCount + 1;
     AdvStringGrid1->RowHeights[AdvStringGrid1->RowCount - 1]  = AdvStringGrid1->RowHeights[AdvStringGrid1->RowCount - 2];
   }
   ProgressBar1->Position = i;
  }
  AdvStringGrid1->EndUpdate();
}
void __fastcall TForm1::DirectoryListBox1Change(TObject *Sender)
{
  LoadImages();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
  AdvPreviewDialog1->Execute();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::UpDown1Click(TObject *Sender, TUDBtnType Button)
{
  if (Button==btNext)
    AdvStringGrid1->ColCount = AdvStringGrid1->ColCount + 1;
  else
     if (AdvStringGrid1->ColCount > 2)
       AdvStringGrid1->ColCount = AdvStringGrid1->ColCount - 1;

   AdvStringGrid1->DefaultColWidth = AdvStringGrid1->ColWidths[1];
   AdvStringGrid1->ColWidths[0] = 16;
   Label1->Caption ="Nr. of columns : " + IntToStr(AdvStringGrid1->ColCount);

 LoadImages();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1GetAlignment(TObject *Sender,
      int ARow, int ACol, TAlignment &AAlignment)
{
  AAlignment = taCenter;
}
//---------------------------------------------------------------------------
