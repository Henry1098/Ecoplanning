//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Uasg14.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "AdvGrid"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
 AdvStringGrid1->SaveFixedCells = FALSE;
 AdvStringGrid1->LoadFromCSV("CARS.CSV");
 AdvStringGrid1->AutoSizeColumns(FALSE,10);
 AdvStringGrid1->InsertCols(0,1);
 AdvStringGrid1->ColWidths[0]=20;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::AdvStringGrid1RightClickCell(TObject *Sender,
      int ARow, int ACol)
{
  if (ARow == 0)
  {

    Label3->Caption = AdvStringGrid1->Cells[ACol][0];

    if ((AdvStringGrid1->GroupColumn != -1) & (ACol >= AdvStringGrid1->GroupColumn))
      ACol++;

    if (AdvStringGrid1->GroupColumn != ACol)
      AdvStringGrid1->GroupColumn = ACol;

  }

}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1GetCellColor(TObject *Sender,
      int ARow, int ACol, TGridDrawState AState, TBrush *ABrush,
      TFont *AFont)
{
  if (AdvStringGrid1->IsNode(ARow))
  {
    ABrush->Color = clGray;
    AFont->Color = clWhite;
  }

}
//---------------------------------------------------------------------------
void __fastcall TForm1::AdvStringGrid1GetCellBorder(TObject *Sender,
      int ARow, int ACol, TPen *APen, TCellBorders &Borders)
{
  if ( (!AdvStringGrid1->IsNode(ARow)) & (ARow > 0))
    Borders = Borders << cbLeft;

  APen->Color = clSilver;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
  AdvStringGrid1->ExpandAll();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
  AdvStringGrid1->ContractAll();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
  AdvStringGrid1->UnGroup();        
}
//---------------------------------------------------------------------------
