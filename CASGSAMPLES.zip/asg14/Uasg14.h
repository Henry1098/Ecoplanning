//---------------------------------------------------------------------------

#ifndef Uasg14H
#define Uasg14H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "AdvGrid.hpp"
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TAdvStringGrid *AdvStringGrid1;
        TButton *Button1;
        TButton *Button2;
        TButton *Button3;
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall AdvStringGrid1RightClickCell(TObject *Sender,
          int ARow, int ACol);
        void __fastcall AdvStringGrid1GetCellColor(TObject *Sender,
          int ARow, int ACol, TGridDrawState AState, TBrush *ABrush,
          TFont *AFont);
        void __fastcall AdvStringGrid1GetCellBorder(TObject *Sender,
          int ARow, int ACol, TPen *APen, TCellBorders &Borders);
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall Button3Click(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
